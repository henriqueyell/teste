package poo.ado;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class POOADO {

    public static void main(String[] args) {
        
         
        String sPIB = "c:/pib.txt";
        String sRegioes = "c:/regioes.txt";
        double []PIB = {1349,462,386,263,239,169,164,159,111,104,
            97,88,87,71,64,52,49,36,35,28,27,26,24,18,8.9,8.7,6.9};
        int iAux = 0;
        int iMult = 100;
        double PibRegiao[] = new double[5];
        String sLinha = null;
        
        
         String arquivoDeSaida = "c:/saida.txt";
         PibRegiao[0] = 27+8.7+64+6.9+88+8.9+18;
         PibRegiao[1] = 52+24+87+36+35+104+28+26+159;
         PibRegiao[2] = 386+97+462+1349;
         PibRegiao[3] = 239+169+263;
         PibRegiao[4] = 49+71+111+164;

        try {

            FileWriter fileWriter = new FileWriter(arquivoDeSaida);

            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            bufferedWriter.write("pib da regiao Norte = "+PibRegiao[0]);
            bufferedWriter.newLine();
            bufferedWriter.write("pib da regiao Nordeste = "+PibRegiao[1]);
             bufferedWriter.newLine();
            bufferedWriter.write("pib da regiao Sudeste = "+PibRegiao[2]);
             bufferedWriter.newLine();
            bufferedWriter.write("pib da regiao Sul = "+PibRegiao[3]);
             bufferedWriter.newLine();
            bufferedWriter.write("pib da regiao Centro-Oeste = "+PibRegiao[4]);

            // feche o arquivo
            bufferedWriter.close();
        }
        catch(IOException ex) {
            System.out.println("Erro de escrita em '" + arquivoDeSaida + "'");
        }    
        
        
        //Impressão dos valores PIB em porcentagem 
        try {
            FileReader fileReader = new FileReader(sPIB);

            BufferedReader bufferedReader = new BufferedReader(fileReader);

            while((sLinha = bufferedReader.readLine()) != null) {
           
                PIB[iAux] = (PIB[iAux]/100)*2;
                
                System.out.println(sLinha+" = "+PIB[iAux]+"%");
                
                iAux++;
            }   

            bufferedReader.close();         
        }
        catch(FileNotFoundException ex) {
            System.out.println("Arquivo inexistente: '" + sPIB + "'");                
        }
        catch(IOException ex) {
            System.out.println("Erro lendo o arquivo '" + sPIB + "'");                  
        }
        
        

        
    }

}
